<?php
// Verifica se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtém o CEP do formulário
    $cep = $_POST["cep"];

    // Verifica se o CEP é válido (você pode adicionar mais validações se necessário)
    if (preg_match('/^\d{5}-?\d{3}$/', $cep)) {
        // Monta a URL da API ViaCEP
        $url = "https://viacep.com.br/ws/$cep/json/";

        // Inicia a requisição cURL
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);

        if ($response) {
            $endereco = json_decode($response, true);

            if (!isset($endereco['erro'])) {
                // Conexão ao banco de dados
                $conexao = new mysqli("localhost", "root", "", "enderecos");

                if ($conexao->connect_error) {
                    die("Erro de conexão: " . $conexao->connect_error);
                }

                // Escapa os dados antes de inserir no banco de dados
                $cep = $conexao->real_escape_string($endereco['cep']);
                $logradouro = $conexao->real_escape_string($endereco['logradouro']);
                $bairro = $conexao->real_escape_string($endereco['bairro']);
                $cidade = $conexao->real_escape_string($endereco['localidade']);
                $estado = $conexao->real_escape_string($endereco['uf']);

                // Insere os dados na tabela do banco de dados
                $sql = "INSERT INTO endereco (cep, logradouro, bairro, cidade, estado) 
                        VALUES ('$cep', '$logradouro', '$bairro', '$cidade', '$estado')";

                if ($conexao->query($sql) === TRUE) {
                    // A linha abaixo foi removida
                    // echo "Dados inseridos com sucesso!<br>";
                } else {
                    echo "Erro ao inserir dados: " . $conexao->error . "<br>";
                }

                $conexao->close();

                // Exibe os dados na página
                echo "CEP: " . $endereco['cep'] . "<br>";
                echo "Logradouro: " . $endereco['logradouro'] . "<br>";
                echo "Bairro: " . $endereco['bairro'] . "<br>";
                echo "Cidade: " . $endereco['localidade'] . "<br>";
                echo "Estado: " . $endereco['uf'] . "<br>";
            } else {
                echo "CEP não encontrado";
            }
        } else {
            echo "Erro ao buscar informações do CEP";
        }
    } else {
        echo "CEP inválido";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Consulta de CEP</title>
</head>
<body>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="cep">Digite o CEP:</label>
        <input type="text" id="cep" name="cep" maxlength="9" pattern="\d{5}-?\d{3}" required>
        <button type="submit">Consultar</button>
    </form>
</body>
</html>
