<?php
session_start();
include("conexaobd.php");

// Processa a edição quando o formulário é enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtém os dados do formulário
    $nome_usuario = $_POST['nome_usuario'];
    $campo_editar = $_POST['campo_editar'];
    $novo_valor = $_POST['novo_valor'];

    // Atualiza o campo no banco de dados
    $query = "UPDATE `tbusuarios` SET `$campo_editar` = '$novo_valor' WHERE `Nome` = '$nome_usuario'";
    $result = mysqli_query($conexaobd, $query);

    if (!$result) {
        die('Erro na atualização: ' . mysqli_error($conexaobd));
    }

    // Redireciona para a página de consulta após a edição
    header("Location: consultar.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Editar Usuário</title>
</head>
<body>

<h2>Editar Usuário</h2>

<form method="post" action="">
    <label for="nome_usuario">Nome do Usuário a ser editado:</label>
    <input type="text" name="nome_usuario" required><br>

    <label for="campo_editar">Campo a ser editado:</label>
    <select name="campo_editar" required>
        <option value="Nome">Nome</option>
        <option value="Telefone">Telefone</option>
        <option value="Celular">Celular</option>
        <option value="Endereço">Endereço</option>
        <option value="Email">E-mail</option>
        <option value="Tipo_de_usuario">Tipo de Usuário</option>
        <option value="Senha">Senha</option>
    </select><br>

    <label for="novo_valor">Novo Valor:</label>
    <input type="text" name="novo_valor" required><br>

    <input type="submit" value="Editar">
</form>

</body>
</html>
