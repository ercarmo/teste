<?php
session_start();
include("conexaobd.php");

// Processa a exclusão quando o formulário é enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtém o nome do usuário a ser excluído do formulário
    $nome_usuario = $_POST['nome_usuario'];

    // Exclui o usuário do banco de dados
    $query = "DELETE FROM `tbusuarios` WHERE `Nome` = '$nome_usuario'";
    $result = mysqli_query($conexaobd, $query);

    if (!$result) {
        die('Erro na exclusão: ' . mysqli_error($conexaobd));
    }

    // Redireciona para a página de consulta após a exclusão
    header("Location: consultar.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Excluir Usuário</title>
</head>
<body>

<h2>Excluir Usuário</h2>

<form method="post" action="">
    Nome do Usuário a ser excluído: <input type="text" name="nome_usuario">
    <input type="submit" value="Excluir">
</form>

</body>
</html>
