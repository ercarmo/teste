<?php
    // a sessão precisa ser iniciada em cada página diferente
    if(!isset($_SESSION)) session_start();

    //verifica se não há a variavel da sessao que identica o usuario
    if(!isset($_SESSION['login'])) {
        //destroi a sessão poir segurança
        session_destroy();
        //redireciona o visitante de volkta para o login
        header("Location: index.php");
        exit;
    }
    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acesso</title>
</head>
<body>
    Acesso completo <br>
    <?php
    $usuario = $_SESSION['login']; 

    echo "Você está logado.";
    ?>

    <h2>Escolha uma opção:</h2>

    <ul>
        <li><a href="consultar.php">Consultar</a></li>
        <li><a href="cadastrar.php">Cadastrar</a></li>
        <li><a href="excluir.php">Excluir</a></li>
        <li><a href="editar.php">Editar</a></li>
        <li><a href="index.php">Sair</a></li>
    </ul>

</body>
</html>
