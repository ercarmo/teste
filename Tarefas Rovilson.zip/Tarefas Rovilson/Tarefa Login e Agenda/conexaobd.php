<?php
    $host = 'localhost';
    $dbname = 'bd2011';
    $usuario = 'root';
    $senha = '';

    // Conectar ao banco de dados
    $conexaobd = new mysqli($host, $usuario, $senha, $dbname);

    // Verificar se a conexão foi bem-sucedida
    if ($conexaobd->connect_error) {
        die("Conexão falhou: " . $conexaobd->connect_error);
    }
   
?>