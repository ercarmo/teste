<?php
session_start();
include("conexaobd.php");

// Consulta todos os registros na tabela tbusuarios do banco de dados
$query = "SELECT * FROM tbusuarios";
$result = $conexaobd->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Consulta</title>
</head>
<body>

<h2>Consulta de Usuários</h2>

<table border="1">
    <tr>
        <th>Nome</th>
        <th>Telefone</th>
        <th>Celular</th>
        <th>Endereço</th>
        <th>E-mail</th>
        <th>Tipo de Usuário</th>
    </tr>

    <?php
    // Exibe os resultados da consulta em uma tabela HTML
    while ($row = $result->fetch_assoc()) :
    ?>
        <tr>
            <td><?= $row['Nome'] ?></td>
            <td><?= $row['Telefone'] ?></td>
            <td><?= $row['Celular'] ?></td>
            <td><?= $row['Endereço'] ?></td>
            <td><?= $row['Email'] ?></td>
            <td><?= $row['Tipo de usuario'] ?></td>
        </tr>
    <?php endwhile; ?> 
</table>

<?php

    echo '<a href="acesso_completo.php"><button>Voltar para a página inicial</button></a>';

?>

</body>
</html>
