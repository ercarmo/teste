<?php
session_start();
include("conexaobd.php");

// Verifica se o usuário tem permissão para acessar a página de cadastro
if ($_SESSION['login'] != 1) {
    header("Location: cadastrar.php");
    exit();
}

// Verifica se o formulário foi submetido
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtém os dados do formulário
    $nome = $_POST['Nome'];
    $telefone = $_POST['Telefone'];
    $celular = $_POST['Celular'];
    $endereco = $_POST['Endereco'];
    $email = $_POST['Email'];
    $tipousuario = $_POST['Tipo_de_usuario']; // Ajuste o nome do campo conforme o formulário
    $senha = $_POST['Senha'];

    // Insere os dados na tabela do banco de dados
    $query = "INSERT INTO `tbusuarios` (`Nome`, `Telefone`, `Celular`, `Endereço`, `Email`, `Tipo de usuario`, `Senha`) VALUES('$nome', '$telefone', '$celular', '$endereco', '$email', '$tipousuario', '$senha')";
    $result = mysqli_query($conexaobd, $query);

    if (!$result) {
        die('Erro na inserção: ' . mysqli_error($conexaobd));
    }

    // Redireciona para a página de consulta após o cadastro
    header("Location: consultar.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cadastro</title>
</head>
<body>

<h2>Cadastro de Usuário</h2>

<form method="post" action="">
    Nome: <input type="text" name="Nome"><br>
    Telefone: <input type="text" name="Telefone"><br>
    Celular: <input type="text" name="Celular"><br>
    Endereço: <input type="text" name="Endereco"><br>
    E-mail: <input type="text" name="Email"><br>
    Tipo de usuário:  <input type="text" name="Tipo de usuario"><br> 
    Senha: <input type="password" name="Senha"><br>
    <input type="submit" value="Cadastrar">
</form>

</body>
</html>

