<?php
// Conexão com o banco de dados
$dsn = 'mysql:host=localhost;dbname=bd2011';
$usuario = 'root';
$senha = '';

try {
    $pdo = new PDO($dsn, $usuario, $senha);
} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
}

// Verifica se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Recebe os dados do formulário
    $Nome = $_POST['login'];
    $senha = $_POST['senha'];
    
    // Prepara a consulta para buscar o usuário no banco de dados
    $stmt = $pdo->prepare('SELECT * FROM tbusuarios WHERE Nome = :Nome');
    $stmt->bindParam(':Nome', $Nome);
    $stmt->execute();


    // Verifica se o usuário existe e se a senha está correta
    if ($usuario = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $usuarioRec = $usuario['Senha'];

        if ($senha == $usuarioRec) {
            session_start();
            $_SESSION['login'] = true;

            // Verifica se o tipo de usuário tem acesso completo ou restrito.
            if ($usuario['Tipo de usuario'] == '1') {
                // Direciona para a página com acesso completo
                header('Location: acesso_completo.php');
            } else {
                // Direciona para a página com acesso restrito
                header('Location: acesso_restrito.php');
            }
        } else {
            echo 'Senha Incorreta.';
            echo '<a href="index.php"><button>Voltar para a página inicial</button></a>';
        }
    } else {
        echo 'Usuário não encontrado';
    }
}
?>
